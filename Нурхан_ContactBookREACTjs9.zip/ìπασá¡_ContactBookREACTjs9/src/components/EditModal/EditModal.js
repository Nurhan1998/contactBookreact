import React, { useState } from "react";
function EditModal(props) {
  let [item, setItem] = useState(props.editContacts);
  function handleEditInput(e) {
    let newObj = { ...item };
    newObj.name = e.target.value;
    setItem(newObj);
  }

  function handleSave() {
    props.handleSaveContacts(item);
    console.log(item);
  }
  return (
    <div className="main-modal">
      <div className="inner-modal">
        <div className="close">
          <button onClick={props.handleCloseModal}>&times;</button>
        </div>
        <input
          type="text"
          onChange={handleEditInput}
          value={item.name}
          className="inp-edit"
        ></input>
        <button onClick={handleSave}>Save</button>
      </div>
    </div>
  );
}

export default EditModal;
