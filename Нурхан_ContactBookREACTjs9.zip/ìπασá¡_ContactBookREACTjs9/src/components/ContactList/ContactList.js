import React from "react";

function ContactList(props) {
  console.log(props);
  return (
    <ul className="contacts">
      {props.contacts.map((item, index) => (
        <li key={index + "a"}>
          name: {item.name} surname: {item.surname} number: {item.number}
          <button onClick={() => props.handleDelete(item.id)}>&times;</button>
          <button onClick={() => props.handleEdit(index)}>Edit</button>
        </li>
      ))}
    </ul>
  );
}

export default ContactList;
